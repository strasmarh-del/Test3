// Banco de preguntas (18) con categorías para desglose
const questions = [
  {id:"Q1",cat:"Servicio",txt:"Un cliente ta' confundido. Tú…",opt:["Le escucho con calma y lo ayudo","Lo mando pa' otro","Que espere ahí","Lo ignoro"],sc:[5,3,1,0]},
  {id:"Q2",cat:"Servicio",txt:"Cuando te agradecen por tu ayuda…",opt:["Me siento bacano ayudando","Es lo normal","Me da igual","Me incomoda"],sc:[5,3,1,0]},
  {id:"Q3",cat:"Servicio",txt:"Ves un problema que afecta un cliente…",opt:["Actúo de una vez","Lo reporto luego","Si me dicen algo lo hago","Lo ignoro"],sc:[5,3,1,0]},
  {id:"Q4",cat:"Servicio",txt:"Hablar con clientes…",opt:["Siempre","A veces","Lo evito","Me estresa"],sc:[5,3,1,0]},
  {id:"Q5",cat:"Servicio",txt:"Lo más importante es…",opt:["Que el cliente se sienta bien","Seguir reglas","Salir rápido","No hablar mucho"],sc:[5,3,1,0]},
  {id:"Q6",cat:"Resolución",txt:"Cliente molesto por un cobro:",opt:["Verifico y explico con calma","Lo mando al gerente","Le digo que ta' errado","Lo ignoro"],sc:[5,3,1,0]},
  {id:"Q7",cat:"Resolución",txt:"Si no sabes la respuesta…",opt:["Pregunto / investigo","Digo que no sé","Culpo al sistema","Invento algo"],sc:[5,3,1,0]},
  {id:"Q8",cat:"Resolución",txt:"Fila larga…",opt:["Calma y rapidez","A mi ritmo","Que esperen","Me pongo nervioso"],sc:[5,3,1,0]},
  {id:"Q9",cat:"Resolución",txt:"Si cometes un error…",opt:["Lo corrijo y aprendo","Lo escondo","Culpo a otro","Me da igual"],sc:[5,3,1,0]},
  {id:"Q10",cat:"Adaptabilidad",txt:"Cambian tareas a última hora:",opt:["Me adapto","Me quilla","Discuto","Me bloqueo"],sc:[5,3,1,0]},
  {id:"Q11",cat:"Adaptabilidad",txt:"Bajo presión…",opt:["Sigo enfocado","Bajo mi ritmo","Me molesto","Me rindo"],sc:[5,3,1,0]},
  {id:"Q12",cat:"Adaptabilidad",txt:"Crítica negativa…",opt:["La uso pa' mejorar","Me siento atacado","Discuto","La ignoro"],sc:[5,3,1,0]},
  {id:"Q13",cat:"Adaptabilidad",txt:"Conflicto entre clientes:",opt:["Mediación con calma","Llamo seguridad","Me desaparezco","Me afecta"],sc:[5,3,1,0]},
  {id:"Q14",cat:"Responsabilidad",txt:"Puntualidad:",opt:["Siempre","A veces","Me atraso","Mucho atraso"],sc:[5,3,1,0]},
  {id:"Q15",cat:"Responsabilidad",txt:"Procesos:",opt:["Cumplo siempre","Si me acuerdo","Da lo mismo","Me lo salto"],sc:[5,3,1,0]},
  {id:"Q16",cat:"Responsabilidad",txt:"Si prometes algo…",opt:["Cumplo","Si puedo","A veces","Da igual"],sc:[5,3,1,0]},
  {id:"Q17",cat:"Responsabilidad",txt:"Info personal del cliente…",opt:["Protegida full","Casi siempre","Se filtra","Me da igual"],sc:[5,3,1,0]},
  {id:"Q18",cat:"Responsabilidad",txt:"Alguien necesita ayuda…",opt:["Ayudo de una","Si me piden","Ignoro","Me molesta"],sc:[5,3,1,0]},
];

const weights = { "Servicio": 0.25, "Resolución": 0.20, "Adaptabilidad": 0.25, "Responsabilidad": 0.30 };
const maxScore = 90;

let idx = 0;
let total = 0;
const catScores = { "Servicio":0, "Resolución":0, "Adaptabilidad":0, "Responsabilidad":0 };
const catCounts = { "Servicio":0, "Resolución":0, "Adaptabilidad":0, "Responsabilidad":0 };

const $ = (sel) => document.querySelector(sel);
const start = $("#start");
const test = $("#test");
const result = $("#result");
const bar = $("#bar");
const question = $("#question");
const options = $("#options");
const counter = $("#counter");
const scoreBox = $("#scoreBox");
const breakdown = $("#breakdown");

function renderQ(){
  bar.style.width = ((idx/questions.length)*100) + "%";
  const q = questions[idx];
  question.textContent = q.txt;
  counter.textContent = `Pregunta ${idx+1} de ${questions.length}`;
  options.innerHTML = "";
  q.opt.forEach((o, i) => {
    const div = document.createElement("div");
    div.className = "option";
    div.textContent = o;
    div.onclick = () => select(i);
    options.appendChild(div);
  });
}

function select(i){
  const q = questions[idx];
  const pts = q.sc[i];
  total += pts;
  catScores[q.cat] += pts;
  catCounts[q.cat] += 1;
  idx++;
  if(idx < questions.length){
    renderQ();
  } else {
    end();
  }
}

function end(){
  test.classList.add("hidden");
  result.classList.remove("hidden");
  let label, cls;
  if(total >= 75){ label = "⭐ Estrella del Servicio"; cls = "green"; }
  else if(total >= 55){ label = "👍 Buen Comunicador"; cls = "yellow"; }
  else { label = "⚠️ Perfil por Desarrollar"; cls = "red"; }

  scoreBox.className = "result-box " + cls;
  scoreBox.innerHTML = `<h3>${label}</h3><p>Puntaje global: <strong>${total}/${maxScore}</strong></p>`;

  // Breakdown por dimensión (promedios simples por ahora)
  breakdown.innerHTML = "";
  Object.keys(catScores).forEach(cat => {
    const maxCat = catCounts[cat] * 5;
    const pct = maxCat ? Math.round((catScores[cat] / maxCat) * 100) : 0;
    const tile = document.createElement("div");
    tile.className = "tile";
    tile.innerHTML = `<h4>${cat}</h4><p>${pct}%</p>`;
    breakdown.appendChild(tile);
  });
}

document.getElementById("btnStart").addEventListener("click", () => {
  start.classList.add("hidden");
  test.classList.remove("hidden");
  renderQ();
});
